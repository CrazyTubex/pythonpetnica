import XCTest
@testable import PerfectNetTests

XCTMain([
     testCase(PerfectNetTests.allTests),
])
