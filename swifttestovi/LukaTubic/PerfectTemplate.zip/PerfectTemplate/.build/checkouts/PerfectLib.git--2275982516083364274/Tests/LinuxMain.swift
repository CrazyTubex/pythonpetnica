import XCTest
@testable import PerfectLibTests

XCTMain([
	testCase(PerfectLibTests.allTests),
])
