import XCTest
@testable import PerfectHTTPTests

XCTMain([
     testCase(PerfectHTTPTests.allTests),
])
