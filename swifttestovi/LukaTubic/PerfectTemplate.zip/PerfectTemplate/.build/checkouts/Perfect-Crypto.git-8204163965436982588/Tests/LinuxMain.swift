import XCTest
@testable import PerfectCryptoTests

XCTMain([
     testCase(PerfectCryptoTests.allTests),
])
